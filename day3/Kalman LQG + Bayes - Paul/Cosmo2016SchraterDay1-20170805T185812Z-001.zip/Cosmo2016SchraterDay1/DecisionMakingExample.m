V_vis = -10:0.01:10;
sig_v = 1;
mu_v = 0.5;
Tview = 50; % Number of evidence steps
fL= @(v)(normpdf(v,-mu_v,sig_v));
fR= @(v)(normpdf(v,mu_v,sig_v));
plot(V_vis,fL(V_vis),V_vis,fR(V_vis)); % Look at the likelihoods

%%
pR = 0.5;
prior = [pR 1-pR]; % The prior - equally weighted

Nsim = 1000; % Number of trials we run through
for trial = 1:Nsim,
    LorR = rand<prior(1);% generate direction
    if LorR,
        v_obs = normrnd(mu_v,sig_v,[1 Tview]);
    else
        v_obs = normrnd(-mu_v,sig_v,[1 Tview]);
    end
    % brute force updating
    for t = 1:Tview
        v_obs_t = v_obs(1:t); % Use samples up to t
        liklihood_R = prod(fR(v_obs_t)); % Get prod likelihood on those samples
        liklihood_L = prod(fL(v_obs_t));
        LR =  log(liklihood_R) - log(liklihood_L); % Take log odds - compute evidence for right
        post = liklihood_R*prior(1)/(liklihood_R*prior(1)+liklihood_L*prior(2)); % Find posterior for right|data
        P_t(t,trial) = post;
        LR_t(t,trial) = LR;
    end
    Hypothesis(trial) = LorR; % True answer - left or right (right = 1).
end

%% Evidence
figure(1)
subplot(1,2,1);
plot(LR_t)
thresh = 4; % Threshold for evidence
R = abs(LR_t)>thresh; % Whether evidence goes above threshold (1 = yes).
PossibleTimes = repmat((1:Tview)',[1,Nsim]); % Possible response times - for each trial
PostCriteriaTimes = R.*PossibleTimes;  PostCriteriaTimes(PostCriteriaTimes==0)=NaN;
reaction_times = nanmin(PostCriteriaTimes); % Find response time
subplot(1,2,2);
hist(reaction_times);
title('Reaction Time Distribution');


%% Probabilities
figure(2);
subplot(1,3,2);
HypothesisByTime = repmat(Hypothesis,[Tview 1]);
Pevidence_t = HypothesisByTime.*P_t + (1-HypothesisByTime).*(1-P_t);
plot(mean(Pevidence_t,2)) % Average posteriors
subplot(1,3,1);
plot(Pevidence_t) % Posteriors 

subplot(1,3,3);
p_crit = 0.95; % Thresold for posteriors
R_post = Pevidence_t>p_crit; % Whether posterior is above threshold (1=yes)
PostCriteriaTimes_post = R_post.*PossibleTimes; PostCriteriaTimes_post(PostCriteriaTimes_post==0)=NaN;
reaction_times_post = nanmin(PostCriteriaTimes_post);
hist(reaction_times_post);
title('Reaction Time Distribution');

