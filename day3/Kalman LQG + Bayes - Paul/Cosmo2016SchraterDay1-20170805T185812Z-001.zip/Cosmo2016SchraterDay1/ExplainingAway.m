% Bayesian Explaining away

% in this project we will develop an "explaining away" model, in two ways =
% via simulation, and by computing the appropriate formula. We will
% simulate the case from the slides, where we observe an object, see
% its imagesize visually, touch its actual size, and need to infer the
% object distance.   
%  Use the following variable conventions, and make all units be logcm
%  (more on why logcm later)
%     Is_d: image of the target
%     Hs: felt size of the target
%     d: distance to target 
%     s:  actual size of the object
%     
%   develop the LIKELIHOOD functions
%     By geometry, the extent of the object on the image is given by 
%       Is_d = s/d
%      However, this is not linear, and moreover, the errors in imagesize
%      discrimination are approximately a fixed percentage of the imagesize
%      itself, suggesting a weber law relationship in the visual sensing of
%      retinal size.  We can thus model the likelihood function for Is_d as
%      originating from
%
%    Is_d = log(s/d) + w_Is,   where w_Is is zero mean Gaussian noise with
%    variance sigma_Is^2 = log(0.02)^2;  
%    
%     Interestingly this is linear in log(d) and log(s), which suggests building Gaussian models in log space 
%    Let
%  
%    Hs = log(s) + w_Hs ,    with variance sigma_Hs^2 = log(0.2)^2; 
%    
%    
%    develop the PRIORS
%   log(s) = N(log(s) | mu_s, sigma_s^2 )  Where mu_s = log(1 cm), var_s = log(2.5)^2 
%   log(2cm)^2  
%   log(d) = N(log(d) | mu_d, sigma_d^2 ) mu_d = log(13cm), var_d = log(7)^2
%

log_s = log(0.01):0.01:log(10);
log_d = log(0.01):0.01:log(50);
% to see the priors
figure(1); subplot(1,2,1);  plot(exp(log_s),normpdf(log_s,log(1),log(2.5)^2))
subplot(1,2,2);  plot(exp(log_d),normpdf(log_d,log(10),log(2.5)^2))


%  Simulate an experiment where distances where distances are sampled from the distance prior and
%  sizes from the size prior on each trial. Compute the Bayesian observer's
%  distance estimates by simulating the observer's choices, and by deriving
%  an implementing the appropriate cue combination formula.  Plot the two
%  predictions for 3 different values of Hs: log(0.25) log(1) log(5)
