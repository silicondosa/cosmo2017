% Load the analysis data needed
load('faceimananalysis.mat');

%%
%  In this tutorial, we will try to discover image features associated with
%  the perception of relative attractivenss.  I have analyzed a face
%  database contributed to "hotornot.com", preprocessed faces, and have
%   compiled the subjective 1-10 rating scale judgments into a score
%   associated with each face. I have picked out 4 prospective features
%   to try out as possibly informative about attractiveness.  Each face image
%   is stored as a vector in a matrix XimavgM. The overall image mean of
% the faces has been removed, so viewing these images requires adding back
% the mean and reshaping the vector into a matrix.  Here is an example:

Im1 = XimavgM(:,100)+M ; % visualize the 100th person
colormap(gray);
imagesc(reshape(Im1,86,86));

%%
% 1)  Use the faceimgui.m script to explore the dimensions and get a sense
% of how the four dimensions might work as (un)attractiveness cues.  
% 2)  We will use regression to try to identify which features are
% associated with attractiveness.

% Attractiveness scores for each face are stored in avgscore
% cue values for the four cues are constructed like this:

% First we project the mean removed faces into the PCA space
x = U(:,1:4)'*XimavgM;

%%
%  You can visualize what these features might do here:
featurenum = 1; % you change this from 1-4 to see each feature as an image
imagesc(reshape(U(:,featurenum),86,86)); 

%%
% Let's try to learn likelihoods for the features to predict 
% attractiveness judgments.

[b1,stats1]=robustfit(avgscore(:),x([ 1 ],:)');
[b2,stats2]=robustfit(avgscore(:),x([ 2 ],:)');
[b3,stats3]=robustfit(avgscore(:),x([ 3 ],:)');
[b4,stats4]=robustfit(avgscore(:),x([ 4 ],:)');

% For each possible cue, b gives a mean function, and robust_s from stats
% gives the stdev.
% Use these to build a likelihood function l_i = log P(x_i | a)

%  How can we test for correlations?

% Compute the Bayes estimate of a, given x coefficients.
% Given a new image, let's subtract off the mean, compute features x, and
% estimate attractiveness.  Now we have the ability to predict which images
% should match based on attractiveness and we can also predict a 1-10
% judgment.  How can we test our feature model?
% 


