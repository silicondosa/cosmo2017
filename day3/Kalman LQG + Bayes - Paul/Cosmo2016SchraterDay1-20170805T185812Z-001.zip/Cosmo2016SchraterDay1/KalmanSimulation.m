%  Implement the kalman filter for the Haith et al theory as described in
%  Schrater's morning lecture, using the kalman_filter.m code provided.
%  Task: Implement the model. Simulate calibration learning with feedback.  
%  You will need to read the paper
% to determine how to set the controls, u. 