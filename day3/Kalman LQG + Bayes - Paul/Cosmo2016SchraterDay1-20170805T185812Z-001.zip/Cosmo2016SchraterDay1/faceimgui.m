load('faceimananalysis.mat');
h=figure(1);
h1 = subplot(1,2,1)
j = 1;
Im1 = XimavgM(:,100)+M ; % visualize the 100th person
colormap(gray);
imagesc(reshape(Im1,86,86))
%image((1-alpha(j))*im(:,:,:,1)+alpha(j)*im(:,:,:,end));
set(h1,'XTick',[])
set(h1,'YTick',[])
p=get(h1,'Position'); p(2) = 0.4; p(4) = 0.5; set(h1,'Position',p)

h2 = subplot(1,2,2)

scalefactors = 2000;  
a = 0.5*[1 1 1 1]';

colormap(gray);

imagesc(reshape(M+scalefactors*U(:,1:4)*(a-0.5),86,86));
set(h2,'XTick',[])
set(h2,'YTick',[])
p=get(h2,'Position'); p(2) = 0.4; p(4) = 0.5; set(h2,'Position',p);
j = 2; jnds(1)=0;
handlea1 = uicontrol(h,'Style','slider','Position',[20 20 300 20],'Value',0.5,'Callback',...
    'a(1) = get(handlea1,''Value''),axis([h1 h2],''off'');imagesc(reshape(M+scalefactors*U(:,1:4)*(a-0.5),86,86),''Parent'',h2);axis([h1 h2],''on'');');
handlea2 = uicontrol(h,'Style','slider','Position',[20 30 300 30],'Value',0.5,'Callback',...
    'a(2) = get(handlea2,''Value''),axis([h1 h2],''off'');imagesc(reshape(M+scalefactors*U(:,1:4)*(a-0.5),86,86),''Parent'',h2);axis([h1 h2],''on'');');
handlea3 = uicontrol(h,'Style','slider','Position',[20 40 300 40],'Value',0.5,'Callback',...
    'a(3) = get(handlea3,''Value'');axis([h1 h2],''off'');imagesc(reshape(M+scalefactors*U(:,1:4)*(a-0.5),86,86),''Parent'',h2);axis([h1 h2],''on'');');
handlea4 = uicontrol(h,'Style','slider','Position',[20 50 300 50],'Value',0.5,'Callback',...
    'a(4) = get(handlea4,''Value'');axis([h1 h2],''off'');imagesc(reshape(M+scalefactors*U(:,1:4)*(a-0.5),86,86),''Parent'',h2);axis([h1 h2],''on'');');

%handle2 = uicontrol(h,'Style','pushbutton','Position',[420 20 80 60],'String','Done','Callback',...
 %    'image((1-a)*im(:,:,:,1)+a*im(:,:,:,end),''Parent'',h1);a,vals(j)=a;vals,j=j+1;jnds = diff(vals); figure(2);plot(cumsum(jnds),jnds,''ro'');figure(1);');
