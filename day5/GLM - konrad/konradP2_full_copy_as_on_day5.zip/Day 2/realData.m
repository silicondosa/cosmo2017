%% real neurons
% This is a dataset from a monkey moving in a real experiment done to test
% decoding. Thanks to Lee  Miller and Jim Rebesco
load datasetReal
imagesc([X y*100]);
colorbar
title('raw data, last column=direction')